def average(num_1, num_2)
    sum = num_1 + num_2
    return sum / 2.0
end

def average_array(arr)
    arr.sum / arr.length.to_f
end

def repeat(str, num)
    str * num
end

def yell(str)
    str.upcase + "!"
end

def alternating_case(sentence)
    arr = sentence.split(' ')
    arr.each.with_index do |word, i|
        if i % 2 == 0
            arr[i] = word.upcase
        else
            arr[i] = word.downcase
        end
    end
    arr.join(' ')
end