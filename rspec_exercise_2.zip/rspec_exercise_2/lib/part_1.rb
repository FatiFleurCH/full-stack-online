def partition(arr, num)
    new_arr = Array.new(2) {Array.new()}
    arr.each do |n|
        if n < num
            new_arr[0] << n
        elsif n >= num
            new_arr[1] << n
        end
    end
    new_arr
end

def merge(hash_1, hash_2)
    new_hash = {}
    hash_1.each { |k, v| new_hash[k] = v }
    hash_2.each { |k, v| new_hash[k] = v }
    new_hash
end

def censor(sentence, arr)
    vowel = "aeiou"
    sentence_arr = sentence.split(' ')
    arr.each do |curse|
        sentence_arr.each do |word|
            if word.downcase == curse
                word.each_char.with_index do |char, i|
                    word[i] = "*" if vowel.include?(char.downcase)
                end
            end
        end    
    end
    sentence_arr.join(' ')
end

def power_of_two?(num)
    return true if num == 1
    return false if num % 2 != 0
    divided = num / 2
    while divided % 2 == 0 
        divided = divided / 2
        return true if divided == 1
        return false if divided % 2 != 0
    end
    return false
   
end