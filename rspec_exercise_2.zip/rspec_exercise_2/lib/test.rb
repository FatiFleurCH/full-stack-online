def censor(sentence, arr)
    vowel = "aeiou"
    sentence_arr = sentence.split(' ')
    arr.each do |curse|
        sentence_arr.each do |word|
            if word.downcase == curse
                word.each_char.with_index do |char, i|
                    if vowel.include?(char.downcase)
                        word[i] = "*"
                    end
                end
            end
        end    
    end
    sentence_arr.join(' ')
end

p censor("Gosh darn it", ["gosh", "darn", "shoot"]) 