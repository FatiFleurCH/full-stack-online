def palindrome?(str)
    new_str = ''
    i = str.length - 1
    str.each_char { |char| new_str = char + new_str }
    if str == new_str
        return true
    else
        return false
    end
end

def substrings(str)
    arr = []
    str.each_char.with_index do |char, i|
        j = i
        rest = ''
        while j < str.length
            rest = rest + str[j]
            arr << rest
            j += 1
        end
    end
    return arr
end

def palindrome_substrings(str)
    arr = []
        substrings(str).each do |sub|        
                arr << sub if palindrome?(sub) if sub.length > 1
        end
        return arr
end